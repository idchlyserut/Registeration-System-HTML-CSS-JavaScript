~Internship Task System for 1 month~
by ID Chlyse Rut

This system is for user-admin where the user is able to submit registeration form and will received by the admin.
The admin on the otherhand is able to view, edit, and delete the application submitted by students. 
The admin can also download the result list of all participants.

This system is created using: HTML, CSS, Javascript, and PHP.
